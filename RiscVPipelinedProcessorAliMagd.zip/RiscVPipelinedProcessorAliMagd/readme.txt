Original instruction set all work as intended.
Assumptions:
- It is going to run one instruction per 2 clock cycles
- Single Memory is not double ported
- PC_In is actually the output of the PC
- PC_Out is actually input of the PC
- AUIPCSel selects between writedata and PC+4
We forgot to include a test for the load- branch case and load use